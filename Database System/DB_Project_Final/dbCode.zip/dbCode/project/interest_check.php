<?php

session_start(); // 세션
include ("connect.php"); // DB접속

$user_id = $_SESSION['id'];

mysql_query("set session character_set_connection=utf8;");
mysql_query("set session character_set_results=utf8;");
mysql_query("set session character_set_client=utf8;");
$post = $_POST['interest'];
$query = "select count(user_id) as A from user_interest ;";
$result = mysql_query($query);
$id_result = mysql_fetch_array($result) ;
$id = $id_result['A'];
$id++;
for($i=0 ; $i<count($post);$i++){
        $sql = mysql_query("insert into user_interest (id,user_id, genre) values (".$id.",".$user_id.",'".$post[$i]."')");	
	$id++;
}
?>
<script type="text/javascript">
                                alert('Interest select Complete');
                                location.href='./index.php';
                        </script>;

