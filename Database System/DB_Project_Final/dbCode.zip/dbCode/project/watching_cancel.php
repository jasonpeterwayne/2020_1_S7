                        <?php
                              session_start(); // 세션
                              include("connect.php");
                              $id = $_SESSION['watching_id'] ;
				$query = "delete from Watching_History_1 where watching_id = '$id' ; " ;
				$watching_query = mysql_query($query) ;
                             // if($watching_query==false) echo mysql_error() ;



                              $HTTP_REFERER = $_SERVER['HTTP_REFERER'];
                              if(!$HTTP_REFERER) $HTTP_REFERER = "/" ;
                             header('Location: '.$HTTP_REFERER);
                        ?>
