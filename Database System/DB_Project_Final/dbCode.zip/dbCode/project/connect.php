﻿<?php
	$servername = "localhost";
	$username = "tldhs";
	$password = "tldhs";
	$dbname = "movie_small";

	// Create connection
	$conn = mysql_connect($servername, $username, $password);
	$dbselect = mysql_select_db($dbname, $conn);

    mysql_query("set session character_set_connection=utf8;");
	mysql_query("set session character_set_results=utf8;");
    mysql_query("set session character_set_client=utf8;");
    
	// Check connection
	if ($conn->connect_error) {
		echo "<script>window.alert('connection fail');</script>";
		die("Connection failed: " . $conn->connect_error);
	}
?>