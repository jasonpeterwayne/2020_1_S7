<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Porphyrio
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130902

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Rotten Naver</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" type="text/css" href="style.css" />

<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->

</head>
<body>
<div id="header-wrapper">
<div id="header" class="container">
                <div id="logo">
                        <h1><a href="#">Rotten Naver</a></h1>
                </div>
                <div id="menu">
                        <ul>
                                <li><a href="index.php" accesskey="1" title="">Homepage</a></li>
                                <li><a href="#" accesskey="2" title="">Our Clients</a></li>
                                <li><a href="#" accesskey="3" title="">About Us</a></li>
                                <li><a href="#" accesskey="4" title="">Careers</a></li>
                                <li><a href="#" accesskey="5" title="">Contact Us</a></li>
                                <li><div class="search-container">
                                        <form action="/action_page.php">
                                          <input type="text" placeholder="Search.." name="search">
                                          <button type="submit"><i>submit</i></button>
                                        </form>
                                </div></li>
                        </ul>
                </div>
        </div>
</div>

<?php

session_start(); // 세션
include ("connect.php");
if($_SESSION['id']==null) { // 로그인 하지 않았다면
    echo "<script>window.alert('**** Service Requires Log In ****');</script>"; // 잘못된 아이디 또는 비빌번호입니다
    echo "<script>location.href='index.php';</script>";
}else{ // 로그인 했다면

   echo "<center><br><br><br>";
   //echo $_SESSION['name']."(".$_SESSION['id'].")님이 로그인 하였습니다.";
echo $_SESSION['name']."(".$_SESSION['id'].") has logged in .";   
echo "&nbsp;<a href='logout.php'><input type='button' value='Logout'></a>";
   echo "</center>";
}

?>

<div id="page" class="container">
        <div id="board_area">
    <h1>Recommandation Page</h1>
    <h4>By Your Gender</h4>
      <table class="list-table">
        <thead>
            <tr>
                <th width="70">#</th>
                  <th width="700">Title</th>
                  <th width="100">Rating</th>
              </tr>
          </thead>
          <?php
            $id = $_SESSION['id'];
            $query = "SELECT birth FROM user_list WHERE user_id = '$id'";
            $result = mysql_query($query);
            $row = mysql_fetch_array($result);
            $birth = $row['birth'];
            $age = substr($birth, 0, 4);
            echo "age: " .$age;
            $current_year = date("Y");
            $age = (int)(($current_year - $age) / 10);
            $age *= 10;
            if($age < 10) $age = 10;
            else if($age > 50) $age = 50;
            echo " AgeGroup: " .$age;
            $query = "SELECT movie_name_kr, movie_name_eng, ROUND((IFNULL((Movielist_Rotten17_20.rating/10),j.rating)+j.rating)/2 , 1) as rating FROM Movielist_Rotten17_20 RIGHT JOIN(
                SELECT movie_name_kr, movie_name_eng, rating FROM Movielist_Naver17_20 JOIN(
                    SELECT movid_id, REPLACE(age_group_$age,'%','') as age FROM Ages_data17_20 WHERE age_group_$age IS NOT NULL) as k ON movid_id = movie_id WHERE CAST(age AS DECIMAL) > 35 ORDER BY likes DESC) as j ON LEFT(movie_name, LENGTH(movie_name)-7) = j.movie_name_eng ORDER BY rating DESC";
           $result = mysql_query($query);
           $count = 1;

           while($count < 21){
                $row = mysql_fetch_array($result);
                $title = $row['movie_name_kr'];
                $title_eng = $row['movie_name_eng'];
                $rating = $row['rating'];
                if($title == "" && $title_eng == "") {
                        $count++;
                        continue;
                }
        ?>
        <tbody>
                <tr>
                        <td width="70"><?php echo $count; ?></td>
                        <td width="500"><a href="movie.php?title_eng=<?php echo $title_eng ?>&title=<?php echo $title ?>"><?php echo $title. " (" .$title_eng.")";?></a></td>
                        <td width="120"><?php echo $rating?></td>
                </tr>
        </tbody>
        <?php
                $count++;}
        ?>
      </table>
      </div>
</div>

<div id="welcome" class="container">
        <h2>Welcome to our website</h2>
        <p>This is <strong>Rotten Naver</strong> we provide you with combined services from both Naver Films and Rotten Tomatoes. Have fun using our website</p>
</div>
<div id="copyright" class="container">
        <p>&copy; Untitled. All rights reserved. | Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
</div>
</body>
</html>
