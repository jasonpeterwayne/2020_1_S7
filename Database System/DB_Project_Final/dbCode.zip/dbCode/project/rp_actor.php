<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Porphyrio
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130902

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Rotten Naver</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" type="text/css" href="style.css" />

<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->

</head>
<body>
<div id="header-wrapper">
<div id="header" class="container">
                <div id="logo">
                        <h1><a href="#">Rotten Naver</a></h1>
                </div>
                <div id="menu">
                        <ul>
                                <li><a href="index.php" accesskey="1" title="">Homepage</a></li>
                                <li><a href="#" accesskey="2" title="">Our Clients</a></li>
                                <li><a href="aboutUs.php" accesskey="3" title="">About Us</a></li>
                                <li><a href="#" accesskey="4" title="">Careers</a></li>
                                <li><a href="#" accesskey="5" title="">Contact Us</a></li>
                                <li><div class="search-container">
                                        <form action="/action_page.php">
                                          <input type="text" placeholder="Search.." name="search">
                                          <button type="submit"><i>submit</i></button>
                                        </form>
                                </div></li>
                        </ul>
                </div>
        </div>
</div>

<?php

session_start(); // 세션
include ("connect.php");
if($_SESSION['id']==null) { // 로그인 하지 않았다면
    echo "<script>window.alert('**** Service Requires Log In ****');</script>"; // 잘못된 아이디 또는 비빌번호입니다
    echo "<script>location.href='index.php';</script>";
}else{ // 로그인 했다면

   echo "<center><br><br><br>";
  // echo $_SESSION['name']."(".$_SESSION['id'].")님이 로그인 하였습니다.";
echo $_SESSION['name']."(".$_SESSION['id'].") has logged in .";  
 echo "&nbsp;<a href='logout.php'><input type='button' value='Logout'></a>";
   echo "</center>";
}

?>

<div id="page" class="container">
        <div id="board_area">
    <h1>Recommandation Page</h1>
    <h4>By Actor</h4>
      <table class="list-table">
        <thead>
            <tr>
                <th width="70">#</th>
                  <th width="700">Title</th>
                  <th width="100">Rating</th>
              </tr>
          </thead>
          <?php
            $id = $_SESSION['id'];
            $query = "SELECT _name, COUNT(_name) as cnt FROM ActorInfo4Naver17_20 JOIN (
                SELECT actor_id FROM Actor4Naver_17_20 JOIN (
                    SELECT i.movie_id FROM (
                        SELECT movie_id, movie_name_kr, movie_name_eng, rating FROM Movielist_Naver17_20 JOIN (
                            SELECT * FROM Watching_History_1 WHERE user_id = '$id') as i ON naver_movie_id = movie_id) as i LEFT JOIN (
                                SELECT movie_id, LEFT(movie_name, LENGTH(movie_name)-7) as movie_name_eng, rating FROM Movielist_Rotten17_20 JOIN (
                                    SELECT * FROM Watching_History_1 WHERE user_id = '$id') as i ON rotten_movie_id = movie_id) as j ON i.movie_name_eng = j.movie_name_eng) as q ON q.movie_id = Actor4Naver_17_20.movie_id) as w ON w.actor_id = ActorInfo4Naver17_20.actor_id GROUP BY _name ORDER BY cnt DESC";
            $result = mysql_query($query);
            $query2 = "SELECT actor_name, COUNT(actor_name) as cnt  FROM ActorInfo4Rotten17_20 JOIN (
                SELECT actor_id FROM Actor4Rotten_17_20 JOIN (
                    SELECT j.movie_id FROM (
                        SELECT movie_id, movie_name_kr, movie_name_eng, rating FROM Movielist_Naver17_20 JOIN (
                            SELECT * FROM Watching_History_1 WHERE user_id = '$id') as i ON naver_movie_id = movie_id) as i RIGHT JOIN (
                                SELECT movie_id, LEFT(movie_name, LENGTH(movie_name)-7) as movie_name_eng, rating FROM Movielist_Rotten17_20 JOIN (
                                    SELECT * FROM Watching_History_1 WHERE user_id = '$id') as i ON rotten_movie_id = movie_id) as j ON i.movie_name_eng = j.movie_name_eng) as w ON Actor4Rotten_17_20.movie_id = w.movie_id) as t ON t.actor_id = ActorInfo4Rotten17_20.actor_id GROUP BY actor_name ORDER BY cnt DESC";
            $result2 = mysql_query($query2);
            if (mysql_num_rows($result) == 0 && mysql_num_rows($result2) == 0) { 
                echo "Not enough Data, Please watch more movies and come back!";
            } else {
                $row = mysql_fetch_array($result);
                $actor_naver = $row['_name'];
                $row = mysql_fetch_array($result2);
                $actor_rotten = $row['actor_name'];
                echo "Actor: ".$actor_naver." / ".$actor_rotten;
                $query = "SELECT * FROM (
                    SELECT movie_name as movie_name_eng, movie_name as movie_name_kr, ROUND(rating/10,1) as rating FROM Movielist_Rotten17_20 JOIN (
                        SELECT movie_id FROM Actor4Rotten_17_20 JOIN (
                            SELECT actor_id FROM ActorInfo4Rotten17_20 WHERE actor_name = '$actor_rotten') as i ON i.actor_id = Actor4Rotten_17_20.actor_id) as j on j.movie_id = Movielist_Rotten17_20.movie_id
                    UNION
                    SELECT movie_name_eng, movie_name_kr, rating FROM Movielist_Naver17_20 JOIN (
                        SELECT movie_id FROM ActorInfo4Naver17_20 JOIN (
                            SELECT actor_id FROM ActorInfo4Naver17_20 WHERE _name = '$actor_naver') as i ON i.actor_id = ActorInfo4Naver17_20.actor_id) as j on j.movie_id = Movielist_Naver17_20.movie_id) as u ORDER BY rating DESC";
                $result = mysql_query($query);
                $count = 1;

                while($count < 21){
                        $row = mysql_fetch_array($result);
                        $title = $row['movie_name_kr'];
                        $title_eng = $row['movie_name_eng'];
                        $rating = $row['rating'];
                        if($title == "" && $title_eng == "") {
                                $count++;
                                continue;
                        }
        ?>
        <tbody>
                <tr>
                        <td width="70"><?php echo $count; ?></td>
                        <td width="500"><a href="movie.php?title_eng=<?php echo $title_eng ?>&title=<?php echo $title ?>"><?php echo $title. " (" .$title_eng.")";?></a></td>
                        <td width="120"><?php echo $rating?></td>
                </tr>
        </tbody>
        <?php
                $count++;}
                        }
        ?>
      </table>
      </div>
</div>

<div id="welcome" class="container">
        <h2>Welcome to our website</h2>
        <p>This is <strong>Rotten Naver</strong> we provide you with combined services from both Naver Films and Rotten Tomatoes. Have fun using our website</p>
</div>
<div id="copyright" class="container">
        <p>&copy; Untitled. All rights reserved. | Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
</div>
</body>
</html>
