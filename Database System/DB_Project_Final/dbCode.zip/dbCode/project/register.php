<?php include ("connect.php"); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="register_style.css">
</head>
<body>
  <div class="header">
  	<h2>Sign Up</h2>
  </div>
  <form method="post" action="registerCheck.php">
  	<div class="input-group">
  	  <label>Username</label>
  	  <input type="text" name="username" placeholder="User Name" required="required">
  	</div>
  	<div class="input-group">
  	  <label>Email</label>
  	  <input type="email" name="email" placeholder="Email" required="required">
  	</div>
  	<div class="input-group">
  	  <label>Password</label>
  	  <input type="password" name="password" required="required" placeholder="Password">
  	</div>
    <div class="input-group">
  	  <label>Birth Day</label>
  	  <input type="birth" name="birth" placeholder="1990-01-01" required="required">
    </div>
    <div class="input-group">
        <label>Gender </label>
        <select name="gender">
        <option value="Male">Male</option>
        <option value="Female">Female</option>
        </select>
    </div>	
    <div class="input-group">
  	  <label>Phone Number</label>
  	  <input type="phone" name="phone" placeholder="01000000000" required="required">
    </div>
    <div class="input-group">
  	  <button type="submit" class="btn" name="registerNewUser">Register</button>
    </div>
    <div>
  		Already have an account?
			<a class="right" href="movie.php">Login</a>
    </div>
  </form>
</body>
</html>

