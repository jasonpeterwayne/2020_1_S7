<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Porphyrio
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130902

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Rotten Naver</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" type="text/css" href="movie_style.css">
<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->


<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#director").click(function(){
    $("#contents").load("/home/project/php/recommand_page/recommand_page.php");
  });
});
</script> -->


</head>
<body>
<div id="header-wrapper">
  <div id="header" class="container">
    <div id="logo">
      <h1><a href="index.php">Rotten Naver</a></h1>
    </div>
    <div id="menu">
      <ul>
        <li><a href="index.php" accesskey="1" title="">Homepage</a></li>
        <li><a href="#" accesskey="2" title="">Our Clients</a></li>
        <li><a href="#" accesskey="3" title="">About Us</a></li>
        <li><a href="#" accesskey="4" title="">Careers</a></li>
        <li><a href="#" accesskey="5" title="">Contact Us</a></li>
        <li>
          <div class="search-container">
            <form action="/action_page.php" method="post">
              <input type="text" placeholder="Search.." name="search">
              <button type="submit"><i>submit</i></button>
</form>
</div>
</li>
</ul>
</div>
</div>
</div>
<?php
session_start(); // 세션
include("connect.php");
if($_SESSION['id']==null) { // 로그인 하지 않았다면
?>
<form name="login_form" action="login_check.php" method="post">
<div class="container_main">
<h2>Login</h2>
<input type="text" name="id" placeholder="email"/><br/>
<input type="password" name="pw" placeholder="password"/>
<input type="submit" class = "button_login" name="login" value="Login">
<a class="button_login" href="register.php">Signup</a>
</div>
</form>
<?php
}else{ // 로그인 했다면
echo "<center><br><br><br>";
//echo $_SESSION['name']."(".$_SESSION['id'].")님이 로그인 하였습니다.";
echo $_SESSION['name']."(".$_SESSION['id'].") has logged in .";
echo "&nbsp;<a href='logout.php'><input type='button' value='Logout'></a>";
echo "</center>";
}

$genre_naver_query = "select distinct genre from Genre4Naver17_20 where genre is not null ;" ;
$genre_naver_result = mysql_query($genre_naver_query);
$genre_rotten_query = "select distinct genre_name from Genre4Rotten17_20 where genre_name is not null ;";
$genre_rotten_result = mysql_query($genre_rotten_query);


?>
<div id="page" class="container">
        <div id = "contents">
                <div class="title">
                        <h2>Interest Genre Select</h2>
              		<form method="post" action="interest_check.php">
			<?php 
				$count = 0;
				while($genre_naver = mysql_fetch_array($genre_naver_result)){
                                $genre_kor = $genre_naver['genre'];
                        ?>
			
			<label><input type="checkbox" name="interest[]" value="<?php echo $genre_kor ?>"><?php echo " ".$genre_kor?></label>
			&nbsp;&nbsp;
			<?php 	
				$count++;
				if($count%10==0) {
					echo '<br>' ;
				}
				} 
			?>
			<br>
			<?php
                                $count = 0;
                                while($genre_rotten = mysql_fetch_array($genre_rotten_result)){
                                $genre_eng = $genre_rotten['genre_name'];
                        ?>
                        
                        <label><input type="checkbox" name="interest[]" value="<?php echo $genre_eng ?>"><?php echo " ".$genre_eng?></label>
                        &nbsp;&nbsp;
                        <?php
                                $count++;
                                if($count%10==0) {
                                        echo '<br>' ;
                                }
                                }
                        ?>
			<p><input type="submit" value="Submit"></p>
			
		</div>
	</div>
</div>
<div id="welcome" class="container">
  <h2>Welcome to our website</h2>
  <p>This is <strong>Rotten Naver</strong> we provide you with combined services from both Naver Films and Rotten Tomatoes. Have fun using our website</p>
</div>
<div id="copyright" class="container">
  <p>&copy; Untitled. All rights reserved. | Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
</div>
</body>
</html>


