                        <?php
                        session_start(); // 세션
                        include("connect.php");
                        $id = NULL;
                        $id = $_SESSION['id'] ;
                        //echo $id ;
                        $watching_naver_id = $_SESSION['watching_naver_id'];
                        $watching_rotten_id = $_SESSION['watching_rotten_id'];
                        $date = date("Y-m-d") ;
                        $id_sql = "select * from Watching_History_1 order by watching_id desc limit 1 " ;
                        $result_id = mysql_query($id_sql);
                        $watching = mysql_fetch_array($result_id);
                        $watching_id = $watching['watching_id']+1;
			//echo $watching_id ;                        
			//echo "naver:".$watching_naver_id ;        
                        if($watching_naver_id==NULL && $watching_rotten_id==NULL) {
                          $watching_query = mysql_query("insert into Watching_History_1 (watching_id, user_id, naver_movie_id, rotten_movie_id, timestamp) values (".$watching_id.", ".$id.", null, null, '$date') ") ;
                        }
                        else if($watching_naver_id==NULL && $watching_rotten_id!=NULL){ 
                          $watching_query = mysql_query("insert into Watching_History_1 (watching_id, user_id, naver_movie_id, rotten_movie_id, timestamp) values (".$watching_id.", ".$id.", null, ".$watching_rotten_id.", '$date') ") ; 
                        }
                        else if($watching_naver_id!=NULL && $watching_rotten_id==NULL) {
                          $watching_query = mysql_query("insert into Watching_History_1 (watching_id, user_id, naver_movie_id, rotten_movie_id, timestamp) values (".$watching_id.", ".$id.", ".$watching_naver_id.", null, '$date') ") ;
                        }
                        else {
                          $watching_query = mysql_query("insert into Watching_History_1 (watching_id, user_id, naver_movie_id, rotten_movie_id, timestamp) values (".$watching_id.", ".$id.", ".$watching_naver_id.", ".$watching_rotten_id.", '$date') ") ;
                        }

                        ?>
                        <script type="text/javascript">
                                alert('Watching History Complete');

                        </script>
                        <?php
                        $HTTP_REFERER = $_SERVER['HTTP_REFERER'];
                        if(!$HTTP_REFERER) $HTTP_REFERER = "/" ;
                        header('Location: '.$HTTP_REFERER);
                        ?>
