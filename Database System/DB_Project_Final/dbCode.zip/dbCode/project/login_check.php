﻿<?php

session_start(); // 세션
include ("connect.php"); // DB접속

$id = $_POST['id']; // 아이디 
$pw = $_POST['pw']; // 패스워드

mysql_query("set session character_set_connection=utf8;");
mysql_query("set session character_set_results=utf8;");
mysql_query("set session character_set_client=utf8;");

$query = "SELECT * FROM user_list WHERE email='$id' AND password ='$pw'";
$result = mysql_query($query); 
$row = mysql_fetch_array($result);

if($id == $row['email'] && $pw == $row['password']){ // id와 pw가 맞다면 login
   $_SESSION['id']=$row['user_id'];
	$user_id = $row['user_id'];
   $_SESSION['name']=$row['name'];
   $interest_query = "select * from user_interest where user_id = '$user_id'; ";
   $interest_result = mysql_query($interest_query) ;
   $interest_row = mysql_fetch_array($interest_result);
   if(mysql_num_rows($interest_result) == 0){
   	echo "<script>location.href='interest.php';</script>";
   }
   else {
     	echo "<script>location.href='index.php';</script>";
   }

}else{ // id 또는 pw가 다르다면 login 폼으로

   echo "<script>window.alert('invalid username or password');</script>"; // 잘못된 아이디 또는 비빌번호입니다
   echo "<script>location.href='index.php';</script>";

}

?>
