<meta charset="utp-8">

<?php include ("connect.php");
  $name=$_POST['username'];
  $password=$_POST['password'];
  $gender_string=$_POST['gender'];
  $birth=$_POST['birth'];
  $email=$_POST['email'];
  $phone_number=$_POST['phone'];

	if($gender_string=='Male'){
		$gender = 0 ;
	}
	else {
		$gender = 1;
	}


    
	$id_sql = "select user_id from user_list order by user_id desc limit 1 " ;
	$result_id = mysql_query($id_sql);
	$user = mysql_fetch_array($result_id);
	
	$user_id = $user['user_id']+1;
	
	$sql = mysql_query("insert into user_list (user_id, password, name, birth, gender, email, phone_number) values (".$user_id.", '".$password."','".$name."', '".$birth."', '".$gender."', '".$email."', '".$phone_number."')");	
?>	



<?php	if($sql){ ?>
		<script type="text/javascript">
			alert('Registr Complete');
			location.href='./index.php';
		</script>;
<?php	} 
	else{
?>
		<script type="text/javascript">
                        alert('Registr Fail');
                        location.href='./index.php';
                </script>;
 <?php	}?>
