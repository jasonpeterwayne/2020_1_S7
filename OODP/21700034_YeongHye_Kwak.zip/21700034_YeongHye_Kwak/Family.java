public interface Family {
	public void accept( Banking v );
	public int returnValue( Banking v );
	public int returnSValue( Banking V );
}
