public interface Banking {
	public void visit( FM1 e );
	public int reValue( FM1 e );
	public int reSValue( FM1 e );
	public void visit( FM2 e );
	public int reValue( FM2 e );
	public int reSValue( FM2 e );
	public void visit( FM3 e );
	public int reValue( FM3 e );
	public int reSValue( FM3 e );
	public void visit( FM4 e );
	public int reValue( FM4 e );
	public int reSValue( FM4 e );
	public void visit( FM5 e );
	public int reValue( FM5 e );
	public int reSValue( FM5 e );
	public void visit( FM6 e );
	public int reValue( FM6 e );
	public int reSValue( FM6 e );
}
